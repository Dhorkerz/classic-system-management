-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 20, 2019 at 02:47 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `classicsystems`
--
CREATE DATABASE `classicsystems` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `classicsystems`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE `adminusers` (
  `UserID` int(7) NOT NULL auto_increment,
  `Username` varchar(100) default NULL,
  `Password` varchar(100) default NULL,
  `Userrole` varchar(255) default NULL,
  PRIMARY KEY  (`UserID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`UserID`, `Username`, `Password`, `Userrole`) VALUES
(1, 'Dorcas', 'adeola1', NULL),
(2, 'admin', '1111', 'supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `certification`
--

CREATE TABLE `certification` (
  `certificateno` int(8) NOT NULL auto_increment,
  `studentid` varchar(10) default NULL,
  `coursecode` varchar(15) default NULL,
  `issued_by` varchar(20) default NULL,
  `received_by` varchar(20) default NULL,
  `date_received` date default NULL,
  PRIMARY KEY  (`certificateno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `certification`
--

INSERT INTO `certification` (`certificateno`, `studentid`, `coursecode`, `issued_by`, `received_by`, `date_received`) VALUES
(1, '', '', '', '', '0000-00-00'),
(2, 'frtik', 'dfhyt', 'cvbn', 'vbnju', '2019-11-13'),
(3, 'frtik', 'dfhyt', 'cvbn', 'vbnju', '2019-11-13'),
(4, '', '', '', '', '0000-00-00'),
(5, '', '', '', '', '0000-00-00'),
(6, '', '', '', '', '0000-00-00'),
(7, '', '', '', '', '0000-00-00'),
(8, '', '', '', '', '0000-00-00'),
(9, '', '', '', '', '0000-00-00'),
(10, '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `classid` varchar(30) default NULL,
  `classname` char(30) default NULL,
  `instructorid` varchar(30) default NULL,
  `date_started` date default NULL,
  `expected_end_date` date default NULL,
  `number_of_students` varchar(10) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`classid`, `classname`, `instructorid`, `date_started`, `expected_end_date`, `number_of_students`) VALUES
(NULL, '', '', '0000-00-00', '0000-00-00', ''),
(NULL, 'web', '009', '2019-11-11', '2019-11-10', '45'),
(NULL, '', '', '0000-00-00', '0000-00-00', ''),
(NULL, '', '', '0000-00-00', '0000-00-00', ''),
(NULL, '', '', '0000-00-00', '0000-00-00', ''),
(NULL, '', '', '0000-00-00', '0000-00-00', ''),
(NULL, '', '', '0000-00-00', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `coursecode` varchar(15) default NULL,
  `coursename` varchar(30) default NULL,
  `duration` varchar(15) default NULL,
  `date_accredited` date default NULL,
  `accredited_by` char(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`coursecode`, `coursename`, `duration`, `date_accredited`, `accredited_by`) VALUES
('001', 'web dev', '3 months', '2019-11-11', 'Supervisor'),
('001', 'web dev', '3 months', '2019-11-11', 'Supervisor'),
('001', 'web dev', '3 months', '2019-11-11', 'Supervisor'),
('001', 'web dev', '3 months', '2019-11-11', 'Supervisor'),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', ''),
('', '', '', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `gradebook`
--

CREATE TABLE `gradebook` (
  `studentid` varchar(10) default NULL,
  `coursecode` varchar(15) default NULL,
  `assignment` varchar(30) default NULL,
  `test` varchar(30) default NULL,
  `practicals` varchar(30) default NULL,
  `exams` varchar(30) default NULL,
  `total` varchar(30) default NULL,
  `average` varchar(30) default NULL,
  `remark` char(30) default NULL,
  `reviewed_by` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gradebook`
--

INSERT INTO `gradebook` (`studentid`, `coursecode`, `assignment`, `test`, `practicals`, `exams`, `total`, `average`, `remark`, `reviewed_by`) VALUES
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', ''),
(NULL, '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `receipt_no` int(15) NOT NULL auto_increment,
  `studentid` varchar(10) NOT NULL default '',
  `coursecode` varchar(15) default NULL,
  `amount_payable` varchar(50) default NULL,
  `amount_paid` varchar(50) default NULL,
  `balance` varchar(50) default NULL,
  `received_by` varchar(20) default NULL,
  `payment_date` date default NULL,
  PRIMARY KEY  (`receipt_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`receipt_no`, `studentid`, `coursecode`, `amount_payable`, `amount_paid`, `balance`, `received_by`, `payment_date`) VALUES
(1, '456', 'java', '95450', '45899', '45420', 'dorcas', '2019-10-02'),
(2, '', '', '', '', '', '', '0000-00-00'),
(3, '', '', '', '', '', '', '0000-00-00'),
(4, '', '', '', '', '', '', '0000-00-00'),
(5, '', '', '', '', '', '', '0000-00-00'),
(6, '', '', '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `prospects`
--

CREATE TABLE `prospects` (
  `UserID` int(7) NOT NULL auto_increment,
  `Fullname` varchar(100) default NULL,
  `Contact_number` varchar(15) default NULL,
  `skill_area` varchar(100) default NULL,
  PRIMARY KEY  (`UserID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `prospects`
--

INSERT INTO `prospects` (`UserID`, `Fullname`, `Contact_number`, `skill_area`) VALUES
(8, 'dorcas', '0908678889', 'web development'),
(12, 'Adeola', '023456778', 'web design'),
(22, 'DORCAS', '0989067', 'WEB DEV'),
(23, 'dorcas', '0908678889', 'web development'),
(24, 'DORCAS', '0908678889', 'web development'),
(25, '', '', ''),
(26, '', '', ''),
(27, '', '', ''),
(28, '', '', ''),
(29, 'ghjjk', 'ghj', '0oiu'),
(30, 'yui', 'yyu', 'bnmm'),
(31, 'fgh', 'dffgh', 'xccvvb'),
(32, 'ghj', 'ghj', 'hjk'),
(33, '', '', ''),
(34, '', '', ''),
(35, '', '', ''),
(36, '', '', ''),
(37, '', '', ''),
(38, '', '', ''),
(39, '', '', ''),
(40, '', '', ''),
(41, '', '', ''),
(42, '', '', ''),
(43, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentid` varchar(10) default NULL,
  `firstname` char(30) default NULL,
  `lastname` char(30) default NULL,
  `email` varchar(30) default NULL,
  `gender` char(10) default NULL,
  `phone` varchar(15) default NULL,
  `address` varchar(30) default NULL,
  `courseinterest` char(30) default NULL,
  `date_registered` date default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentid`, `firstname`, `lastname`, `email`, `gender`, `phone`, `address`, `courseinterest`, `date_registered`) VALUES
(NULL, 'dorcas', 'dorc', 'Bimps@yahoo.com', 'female', '090678945', 'asdf', 'web', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00'),
(NULL, '', '', '', '', '', '', '', '0000-00-00');
